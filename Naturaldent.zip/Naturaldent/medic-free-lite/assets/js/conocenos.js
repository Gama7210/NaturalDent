// Activar animación flip manual si deseas
document.getElementById("businessCard").addEventListener("click", function () {
  this.classList.toggle("flipped");
});
// Future JS enhancements (if needed)
console.log("Página Conócenos lista.");

